package com.bootcamp.jdbcjpahibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcjpahibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
